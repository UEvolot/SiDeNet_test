import sys
# noinspection PyUnresolvedReferences
import os
sys.path.append('D:/Data/pythonProject/SiDeNet_v2/SiDeNet_v2/src/')
sys.path.append('D:/Data/pythonProject/SiDeNet_v2/SiDeNet_v2/src/train/')
sys.path.append('D:/Data/pythonProject/SiDeNet_v2/SiDeNet_v2/src/projection/')

import numpy as np
# noinspection PyUnresolvedReferences
import cv2
np.random.seed(0)
EPS = 1e-5
DEBUG=False
import torch.nn as nn
import torch
from torch.autograd import Variable, Function
import torch.nn.functional as F
from src.train.utils.statistics import _get_iou_mask_accuracy_for_tensor
from scipy.ndimage.morphology import distance_transform_edt
from src.train.Net.Decoders import Decoder2DTowerLarge
from src.train.Net.Decoders import Decoder2DTowerResNet
from src.train.Net.Projection import Projection, RotateBox, PTN
from src.train.Net.Decoder2DTower import Decoder2DTower
from src.train.Net.Decoder3D import Decoder3DTower
from src.train.Net.SkipNet import simpleNet, MLP
torch.manual_seed(0)
torch.cuda.manual_seed(0)


torch.set_num_threads(1)


from src.train.utils.Globals import *
class AngleEncoder(nn.Module):
	def __init__(self):
		super(AngleEncoder, self).__init__()
		self.compute_stats = False

		# Pass through some non-linearities
		self.fv_1 = nn.Conv2d(2, 32, 1)
		self.fv_2 = nn.Conv2d(32, 1024, 1)

	def forward(self, theta):
		return F.relu(self.fv_2(F.relu(self.fv_1(theta)))).view(theta.size(0), 512,2,1).contiguous()


'''
预测轮廓图：输出结果为（loss，轮廓图）
'''
class SilhouettePrediction(nn.Module):
	def __init__(self, num_input_channels=512, num_output_channels=1, additional_param=3):
		super(SilhouettePrediction, self).__init__()
		self.compute_stats = False

		if USE_SHAPENET and SMALL_DECODER_3D:
			self.extra_non_lin = nn.Conv2d(num_input_channels, num_input_channels, 1, bias=True)
			self.PTN = PTN(57,57,57)
			self.decoder = Decoder3DTower(num_input_channels)
		elif SMALL_DECODER_3D:
			self.extra_non_lin = nn.Conv2d(num_input_channels, num_input_channels, 1, bias=True)
			self.rotate_box = RotateBox(57,57,57)
			self.decoder = Decoder3DTower(num_input_channels)
			print("SMALL_DECODER_3D")
		elif SMALL_DECODER:
			self.decoder = Decoder2DTower(num_input_channels+32)
			print("SMALL_DECODER")
		# 使用NORMAL_DECODER
		else:
			self.decoder = Decoder2DTowerLarge(num_input_channels+64, num_output_channels=num_output_channels, norm_type='batch')
			print("NORMAL_DECODER")

		# Pass through some non-linearities：输入新角度
			self.fv_1 = nn.Conv2d(2, 32, 1)
			self.fv_2 = nn.Conv2d(32, 32, 1)
			self.full_simpleNet = simpleNet()

		self.MLP = MLP()
	def forward(self, theta, fv_height, ref_seg):  # ref_seg是gt图
		# theta = theta.cuda()
		fv_height = fv_height.cuda()
		ref_seg = ref_seg.cuda()
		#null_vector = F.relu(self.fv_2(F.relu(self.fv_1(theta)))).cuda() # 角度处理结果
		info = []
		for j in range(0, len(theta)):
			print(theta[j])
			theta[j] = torch.squeeze(theta[j], 0)
			print(theta[j].shape)
			info.append(theta[j].cpu().numpy())
		print(info)
		data = []
		for j in range(0, 3):
			for k in info[j]:
				data.append(k)
		for j in range(3, 6):
			data.append(info[j])
		print('data', data)
		null_vector = (self.full_simpleNet(torch.Tensor(np.array(data).astype(float)).cuda())).view(1, 64, 1, 1)

		if USE_SHAPENET and SMALL_DECODER_3D:
			fv_height = F.relu(self.extra_non_lin(fv_height))
			xc = self.decoder(fv_height.unsqueeze(4))
			theta = torch.atan2(theta[:,1,:,:], theta[:,0,:,:])
			xc = self.PTN(xc, theta)
			xc = xc.max(dim=2)[0]

		elif SMALL_DECODER_3D:
			fv_height = F.relu(self.extra_non_lin(fv_height))
			xc = self.decoder(fv_height.unsqueeze(4))
			theta = torch.atan2(theta[:,1,:,:], theta[:,0,:,:])
			xc = Projection()(xc, theta)
			xc = xc.min(3)[0].squeeze(3).transpose(3,2)
			ref_seg = 1 - ref_seg
		
		else:
			# 将角度CNN输出角度和特征图拼接并输入decoder网络得出轮廓图
			xc = self.decoder(torch.cat((fv_height, null_vector), 1))

		# Disregard those without silhouettes
		if True:
			weights = np.zeros(ref_seg.data.cpu().numpy().shape)
			for i in range(0, ref_seg.size(0)):
				# distance_transform_edt 计算图像中非零点到最近背景点（即0）的距离并用它替换原来的像素值
				weightsinside = distance_transform_edt(ref_seg.data[i,0,:,:].cpu().numpy())
				weightsoutside = distance_transform_edt((1 - ref_seg.data[i,0,:,:]).cpu().numpy())
				weights[i,:,:,:] = weightsinside + weightsoutside

			if True:
				weights[weights > 20] = 5
			
			weights = torch.Tensor(weights).clamp(min=0, max=20)
			print('weights', weights)

		select_PIX = {}
		if nn.BCEWithLogitsLoss(weight=weights).cuda()(xc, ref_seg) < -0.05:
			xc_F = F.sigmoid(xc)
			xc_Final = xc_F[0][0]
			ref_seg_F = ref_seg[0][0]
			for i in range(0, len(xc_Final)):
				for j in range(0, len(xc_Final[i])):
					if xc_Final[i][j] != ref_seg_F[i][j]:
						x = torch.zeros([1,1,1,3],dtype=torch.float).cuda()
						x[0][0][0][0] = xc_Final[i][j]
						x[0][0][0][1] = i
						x[0][0][0][2] = j
						select_PIX[(i,j)] = F.sigmoid(self.MLP(x))[0][0]
						xc_F[0][0][i][j] = select_PIX[(i,j)]

			return nn.BCELoss(weight=weights).cuda()(xc_F, ref_seg), Variable(xc_F.data)

		else:
			'''
			accuracy, total_num, acc_by_id = _get_iou_mask_accuracy_for_tensor(F.sigmoid(xc), ref_seg)
			print('useIOU')
			return nn.BCEWithLogitsLoss(weight=weights).cuda()(xc, Variable(xc.data).cuda()), accuracy / total_num, Variable(F.sigmoid(xc).data), acc_by_id
			'''
			return nn.BCEWithLogitsLoss(weight=weights).cuda()(xc, ref_seg), Variable(F.sigmoid(xc).data)	 # 返回结果



