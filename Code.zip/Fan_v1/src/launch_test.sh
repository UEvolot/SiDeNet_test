﻿# Testing Scripts:

# SCULPTURE DATASET
# Trained with 3views, tested with 1 view
python oc_pytorch/src/train/train_meshnet.py --test --old_model ./models/3views_trained.pth --imdb LOCATION_OF_IMDB --dataset sculpture --num_views 0 --cuda --testBatchSize 1 --loss DepthSilLoss
# python train/train_meshnet.py --test --old_model ./models/3views_trained.pth --imdb LOCATION_OF_IMDB --dataset sculpture --num_views 0 --cuda --testBatchSize 1 --loss DepthSilLoss

# Trained with 3views, tested with 2 view
python oc_pytorch/src/train/train_meshnet.py --test --old_model ./models/3views_trained.pth --imdb LOCATION_OF_IMDB --dataset sculpture --num_views 1 --cuda --testBatchSize 1 --loss DepthSilLoss

# Trained with 3views, tested with 3 view
python oc_pytorch/src/train/train_meshnet.py --test --old_model ./models/3views_trained.pth --imdb LOCATION_OF_IMDB --dataset sculpture --num_views 2 --cuda --testBatchSize 1 --loss DepthSilLoss


# SHAPENET: NEED to set GLOBALS.USE_SHAPENET to True
# Note that will print out values for L1 but these can be safely ignored, so just Sil IoU is important.
