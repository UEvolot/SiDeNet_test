#!/bin/bash
export OMP_NUM_THREADS=5
export CUDA_DEVICE=0

model_epoch_path='/scratch/shared/slow/ow/python_epochs/sidenet/'
dataset='shapenet'
python ./oc_pytorch/src/train/train_meshnet.py \
           --dataset $dataset --imdb '/scratch/local/ssd/ow/' --type_of_model 'MeshBasedPrediction' --adam True \
            --model_epoch_path $model_epoch_path --threads 10 --epoch 41 --cuda --cuda_device 3 --use_large 'pix2pix' --continue_epoch 0 --max_theta 24 \
           --batchSize 16 --testBatchSize 16 --num_views 2 --loss 'DepthSilLoss' --lr 0.001 --suffix '' --lambda1 1 --lambda2 1 \
	  --old_model '/scratch/shared/slow/ow/python_epochs/ablation/theta_angles//shapenet/MeshBasedPrediction_adam/pix2pix_none/num_views2_batchsize_16finetuneFalse_loss_DepthSilLoss_lambda1_21.0_1.0DepthSilLoss_0.001_size_pix2pix_nv2_mt16theta_16model_epoch_best.pth'


