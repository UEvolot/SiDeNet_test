import cv2
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from tensorboardX import SummaryWriter
import torch

writer = SummaryWriter('D:/Data/code/runs1/sidenet/sculpture__nv10_mt24')

depth_path = 'E:/BaiduNetdiskDownload/image_silnet_origional/image_silnet_origional/img_subset1/3.exr.tiff'
# mask_path = 'D:/SilNet/image_silnet_origional0/image_silnet_origional/img_subset1/1.jpg'
n = Image.open("C:/Users/n8300/Desktop/作业/individualImage2.png")
plt.imshow(n, cmap='jet')
plt.show()

depth = Image.open(depth_path)
# mask = Image.open(mask_path)
depth = torch.Tensor(np.array(depth.resize((1024,1024), Image.NEAREST))).unsqueeze(0)
print(depth)
print("depth")
print(depth.min())
print(depth.max())
depth[depth == 60] = 0
print(depth.max())
depth = depth / depth.max()

print("depth")
mask = (depth > 0).float()
gt_depth = depth * (mask > 0.5).float()
print(gt_depth)
print(gt_depth.min())
print(gt_depth.max())
'''
writer.add_image('D:/Data/code/runs1/sidenet/Train/input%d_%d' % (1, 1), gt_depth.data)

gt_depths = cv2.imread('E:/BaiduNetdiskDownload/image_silnet_origional/image_silnet_origional/img_subset1/3.exr.tiff', cv2.IMREAD_UNCHANGED)
cv2.namedWindow('input_image', cv2.WINDOW_AUTOSIZE)
plt.imshow(gt_depths, cmap='jet')
plt.show()
'''