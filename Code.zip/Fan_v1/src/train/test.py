class DatasetFromTxtFileSculptures(data.Dataset):
    def __init__(self, txt_file, use_mask=False, input_scale=256, output_scale=256,
                 num_views=3, dataset_id=1, theta_transform=None,
                 input_transform=None, seg_transform=None, random=0, mean=None, test_augmentation=False,
                 ):
        """
        Instantiates the dataset. Note that the index specifies whether is test/val/train
        """
        super(DatasetFromTxtFileSculptures, self).__init__()
        self.dataset_id = dataset_id
        self.test_augmentation = test_augmentation
        assert (len(dataset_id) == 1)

        self.images = np.load(txt_file[0] + '/angles_reshaped.npy').astype('|S200')
        print("记录！")
        print(txt_file)
        print(self.images)
        print(self.images.shape)
        for i in range(1, len(txt_file)):
            self.images = np.vstack((self.images, np.load(txt_file[i] + '/angles_reshaped.npy').astype('|S200')))

        print("记录！", self.images.shape)
        print(self.images[0, :])
        self.images = self.images[self.images[:, -1].astype(np.float32).round() == dataset_id[0], :]
        print(self.images)
        print(self.images.shape)
        for i in range(0, self.images.shape[0]):
            self.images[i, -2] = bytes.decode(self.images[i, -2]).replace('augmented_additionalsculptures',
                                                                          txt_file[0] + '/augment_additionalsculptures')
            self.images[i, -2] = bytes.decode(self.images[i, -2]).replace('newtextures_oldsculptures', txt_file[
                0] + '/newtextures_oldsculptures/depth/')
            self.images[i, -2] = bytes.decode(self.images[i, -2]).replace('image_silnet_origional', txt_file[
                0] + '/image_silnet_origional/')  # 只执行了这一行

        print(self.images.shape)
        t = self.images[:, 0]
        print(t.shape[0])
        print("tshape")
        for i in range(0, t.shape[0]):
            t[i] = bytes.decode(self.images[i, -2]) + bytes.decode(t[i])  # t是所有雕塑文件夹路径
        self.num_views = num_views
        self.rng = np.random.RandomState(random)
        self.use_mask = use_mask
        self.random_view_selection = False
        self.seg_transform = seg_transform(scale=output_scale)  # output时给剪影变形
        self.input_segtransform = seg_transform(scale=input_scale)  # 输入剪影变形
        self.input_scale = input_scale
        self.output_scale = output_scale
        self.theta_transform = theta_transform

        self.idx = 0
        print("MEAN", mean, self.num_views)
        if mean == None:

            print(t[0], BASE_FILE_TO_DIR)

            self.mean = get_avg_images(t, BASE_FILE_TO_DIR, '/1.png', 100)
            print("NEW MEAN", self.mean)
            self.input_transform = input_transform(mean=self.mean, scale=input_scale)
        else:
            self.mean = mean
            self.input_transform = input_transform(mean=self.mean, scale=input_scale)

    def __len__(self):
        return self.images.shape[0] - 1

    def __getitem__(self, orig_index):
        if self.dataset_id == 3 or self.dataset_id == 2:
            self.rng = np.random.RandomState(orig_index)

        FAILED_LOAD = False

        if self.test_augmentation:  # False
            orig_index = int(orig_index / 20)
            angle_index = orig_index * 20
            index = orig_index * 20 + self.rng.randint(20)
        else:
            index = orig_index
            angle_index = int(orig_index / 20) * 20

        if hasattr(self, 'views'):
            views = [v + 1 for v in self.views[:-1]]
        else:
            list1 = []
            for ind in range(1, 11):
                list1.append(ind)
            # views = self.rng.choice(list1, 800, replace=False)	 # 这里要删掉才行，在下面用个for读取用作轮廓图的部分
            views = list1
            # views = views[0:(self.num_views+1)]
            print("verify2", views)
        if not os.path.exists(BASE_FILE_TO_DIR + bytes.decode(self.images[index, 0]) + '/' + str(views[0]) + '.png'):
            print("WARNING:: Missing %s" % (
                        BASE_FILE_TO_DIR + bytes.decode(self.images[index, 0]) + '/' + str(views[0]) + '.png'))
            seg_view = torch.zeros(1, self.output_scale, self.output_scale)
            input_seg = torch.zeros(1, self.input_scale, self.input_scale)
            index = 0
            input_img = torch.zeros(3, self.input_scale, self.input_scale)
            seg_theta = torch.Tensor(
                get_sin_cos(torch.Tensor(np.array([self.images[index, views[0]].astype(np.float32)]))))

            FAILED_LOAD = True

        else:
            print(index)
            print("index")
            seg_name = BASE_FILE_TO_DIR + bytes.decode(self.images[index, 0]) + '/' + str(views[0]) + '.exr.tiff'
            target_name = BASE_FILE_TO_DIR + bytes.decode(self.images[index, 0]) + '/' + str(views[0]) + '.png'
            print(angle_index)
            print("angle_index")
            seg_theta = torch.Tensor(get_sin_cos((np.array([self.images[angle_index, views[0]].astype(np.float32)]))))
            input_seg = load_any_img(seg_name)
            input_img = load_img(target_name)
            print("12345", np.asarray(input_seg))
            input_img = self.input_transform(input_img)

            try:
                # print("input_seg")
                # print(input_seg)
                # print(torch.Tensor(np.array(input_seg.resize((self.output_scale,self.output_scale), Image.NEAREST))))
                input_seg = (torch.Tensor(np.array(
                    input_seg.resize((self.output_scale, self.output_scale), Image.NEAREST))) < 60).float().unsqueeze(0)
                print("input_seg", input_seg)
            except:
                print(seg_name)
                print('FAILED')
                print(1 + seg_name)

            input_seg_subsample = input_seg

        imgs = ''

        views = views[1:]
        print("views2")
        img_view_name = [0] * len(views)
        seg_view_name = [0] * len(views)

        img_views_no_transformation = [0] * len(views)
        img_views = [0] * len(views)
        theta_views = [0] * len(views)
        depth_views = [0] * len(views)
        seg_views = [0] * len(views)
        seg_subsample_views = [0] * len(views)
        subsample_masks = [0] * len(views)
        for i in range(0, len(views)):
            if self.test_augmentation:
                index = orig_index * 20 + self.rng.randint(20)
            img_view_name[i] = BASE_FILE_TO_DIR + bytes.decode(self.images[index, 0]) + '/' + str(views[i]) + '.png'
            seg_view_name[i] = BASE_FILE_TO_DIR + bytes.decode(self.images[index, 0]) + '/' + str(
                views[i]) + '.exr.tiff'
            depth_views[i] = BASE_FILE_TO_DIR + bytes.decode(self.images[index, 0]) + '/' + str(views[i]) + '.exr.tiff'
            theta_views[i] = self.images[angle_index, views[i]].astype(np.float32)
            if not os.path.exists(img_view_name[i]):
                print("WARNING: Input image doesn't exist", img_view_name[i])
                img_views[i] = torch.zeros(3, 256, 256)
                seg_views[i] = torch.zeros(1, 256, 256)
                depth_views[i] = torch.zeros(1, 256, 256)
                seg_subsample_views[i] = torch.zeros(3, 256, 256)
                img_views_no_transformation[i] = torch.zeros(3, 256, 256)
                FAILED_LOAD = True


            else:
                img_view = load_img(img_view_name[i])
                seg_view = load_any_img(seg_view_name[i])
                depth_view = load_any_img(depth_views[i])
                print("depth_view", depth_view)
                if self.input_transform:
                    img_view_no_transformation = self.input_segtransform(img_view)
                    img_view = self.input_transform(img_view)
                    print("img_view", img_view)
                    img_views[i] = img_view
                    try:
                        depth_views[i] = torch.Tensor(np.array(
                            depth_view.resize((self.output_scale, self.output_scale), Image.NEAREST))).unsqueeze(0)
                        print("depth_views0", depth_views)
                    except:
                        print(img_view_name[i])
                        print('FAILED')
                        print(1 + img_view_name[i])

                    depth_views[i][depth_views[i] == 60] = 0
                    seg_views[i] = (depth_views[i] > 0).float()  # 将>0的设为1，<=0设为0
                    print("seg_view", seg_views)
                    print("depth_views1", depth_views)

                    depth_views[i] = torch.Tensor(
                        np.array(depth_view.resize((self.input_scale, self.input_scale), Image.NEAREST))).unsqueeze(0)
                    depth_views[i][depth_views[i] == 60] = 0
                    subsample_masks[i] = (depth_views[i] > 0).float()  # 将>0的设为1，<=0设为0
                    print("depth_views2", depth_views)
                    print("subsample_masks", subsample_masks)
                    # img_views[i] = (seg_views[i]).expand_as(img_views[i])
                    img_views_no_transformation[i] = img_view_no_transformation
                    seg_subsample_views[i] = seg_views[i]
            theta_views[i] = torch.Tensor(get_sin_cos(theta_views[i]))
        '''
        img_views: 数据集中的雕塑中索引为index的4张png图片进行变换后得到的每个图片数组形成的列表
        seg_views: 数据集中的雕塑中索引为index的4张exr图片resize和与10比较后(使得其中所有元素>10的设为0)得到的tensor数组进行扩维后得到depth_views，再和0比()得到全为0、1的数组
        theta_views: 得到一个数组存储关于在npy数据数组中的数据集索引为angle_index，内部索引1到5中随机4个的元素为对应视图的角度theta的sin,cos
        input_img: 数据集中的雕塑中索引为index的5张png图片中剩下那张进行变换后得到的一个图片数组
        input_seg: 数据集中的雕塑中索引为index的5张exr图片中剩下那张resize再与10、0比较后(使得其中所有元素>10的设为0，<10的设为1)得到的tensor数组，进行扩维后的结果
        seg_theta: 得到一个数组存储关于在npy数据数组中的数据集索引为angle_index，内部索引1到5中的剩下的元素为对应视图的角度theta的sin,cos
        seg_subsample_views: 与seg_views一样
        depth_views: 数据集中的雕塑中索引为index的4张exr图片resize成input_scale大小，进行扩维后，和与10比较后(使得其中所有元素>10的设为0)得到的tensor数组
        subsample_masks: 数据集中的雕塑中索引为index的4张exr图片resize成input_scale大小，和与10比较后(使得其中所有元素>10的设为0)得到的tensor数组, 再和0比得到结果
        img_views_no_transformation: 数据集中的雕塑中索引为index的4张png图片进行scale变换后得到的每个图片数组形成的列表
        '''
        print("views3")
        return [img_views, seg_views, theta_views, input_img, input_seg, seg_theta, seg_subsample_views, depth_views,
                subsample_masks, img_views_no_transformation]