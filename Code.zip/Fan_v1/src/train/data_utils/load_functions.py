import numpy as np
from PIL import Image
import cv2

def load_any_img(file_path):
	# img = cv2.imread(file_path)
	img = Image.open(file_path)
	# img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
	# img = Image.fromarray(img)
	return img

def load_img(file_path):
	img = Image.open(file_path).convert('RGB')
	return img

def get_sin_cos(theta):
	return np.array([[np.sin(2*np.pi*theta)], [np.cos(2*np.pi*theta)]])

def get_sincos(theta):
	print('print theta',theta)
	print(np.array([np.sin(2*np.pi*theta), np.cos(2*np.pi*theta)]))
	return np.array([np.sin(2*np.pi*theta), np.cos(2*np.pi*theta)])