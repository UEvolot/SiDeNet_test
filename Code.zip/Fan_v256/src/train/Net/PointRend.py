import torch.nn as nn
import torch.nn.functional as F
import torch
from src.train.Net.SkipNet import MLP

def PRend(xc, ref_seg):
    select_PIX = {}
    xc_F = F.sigmoid(xc)
    xc_Final = xc_F[0][0]
    ref_seg_F = ref_seg[0][0]
    for i in range(0, len(xc_Final)):
        for j in range(0, len(xc_Final[i])):
            if xc_Final[i][j] != ref_seg_F[i][j]:
                x = torch.zeros([1 ,1 ,1 ,3] ,dtype=torch.float).cuda()
                x[0][0][0][0] = xc_Final[i][j]
                x[0][0][0][1] = i
                x[0][0][0][2] = j
                select_PIX[(i, j)] = F.sigmoid(MLP(x))[0][0]
                xc_F[0][0][i][j] = select_PIX[(i, j)]
    return xc_F